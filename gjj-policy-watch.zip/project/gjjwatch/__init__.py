"""gjj-policy-watch：公积金政策监测系统。"""

__version__ = "1.0.0"
